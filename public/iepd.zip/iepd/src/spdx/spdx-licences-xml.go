package main

import (
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"xsdprov"

	libxml2 "github.com/lestrrat/go-libxml2"
	"github.com/lestrrat/go-libxml2/xsd"
)

//SpdxLicenses ...
type SpdxLicenses struct {
	SpdxLicense []SpdxLicense `xml:"License,omitempty"  json:"string[],omitempty"`
	XMLName     xml.Name      `xml:"RDF,omitempty"  json:"RDF,omitempty"`
}

//SpdxLicense ...
type SpdxLicense struct {
	About         string   `xml:"about,attr,omitempty"  json:"about,omitempty"`
	LicenseID     string   `xml:"licenseID,omitempty"  json:"licenseID,omitempty"`
	RDFLicenseURL string   `xml:"rdfLicenseURL,omitempty"  json:"rdfLicenseURL,omitempty"`
	XMLLicenseURL string   `xml:"xmlLicenseURL,omitempty"  json:"xmlLicenseURL,omitempty"`
	Digest        string   `xml:"digest,omitempty"  json:"digest,omitempty"`
	Valid         bool     `xml:"valid,omitempty"  json:"valid,omitempty"`
	Message       string   `xml:"message,omitempty"  json:"message,omitempty"`
	XMLName       xml.Name `xml:"License,omitempty"  json:"License,omitempty"`
}

// ValErrs ... http error id
type ValErrs struct {
	Status  bool   `json:"status,omitempty"`
	Error   string `json:"error,omitempty"`
	Message string `json:"message,omitempty"`
}

var spdxrdfpath = "https://github.com/spdx/license-list-data/raw/master/rdfxml/"

var spdxlicencelist = "https://github.com/spdx/license-list-data/raw/master/rdfxml/licenses.rdf"

var licensexsl = "../../xml/xsl/make_license.xsl"

var licensedigests = map[string]string{}

var resources = map[string]string{}

//NewLicenseList ...
func NewLicenseList() *SpdxLicenses {
	return &SpdxLicenses{}
}

//MakeLicenses ...
func MakeLicenses(resrces map[string]string, tpath string) {
	resources = resrces
	var temppath = tpath
	if _, err := os.Stat(temppath + resrces["licenses.rdf"]); os.IsNotExist(err) {
		err := wgetF(temppath+resrces["licenses.rdf"], spdxlicencelist)
		check(err)
	}
	xf, ferr := ioutil.ReadFile(temppath + resrces["licenses.rdf"])
	check(ferr)
	var liclist = NewLicenseList()
	lerr := xml.Unmarshal([]byte(xf), &liclist)
	check(lerr)
	for i, lic := range liclist.SpdxLicense {
		var n = filepath.Base(lic.About)
		liclist.SpdxLicense[i].LicenseID = n
		var p = spdxrdfpath + n + ".rdf"
		liclist.SpdxLicense[i].RDFLicenseURL = p
		var rdfpath = temppath + "resources/rdfxml/" + n + ".rdf"
		var outpath = "resources/licenses/" + n + ".xml"
		liclist.SpdxLicense[i].XMLLicenseURL = outpath
		var xsl = temppath + resrces["make_license.xsl"]
		cmd := exec.Cmd{
			Args: []string{"xsltproc", xsl, rdfpath},
			Env:  os.Environ(),
			Path: "/usr/bin/xsltproc",
		}
		resultstring, err := cmd.Output()
		check(err)
		var licpath = temppath + outpath
		werr := ioutil.WriteFile(licpath, resultstring, 0666)
		check(werr)
		licensedigests[n+".xml"] = xsdprov.GetHash(temppath+outpath, "Sha256")
		liclist.SpdxLicense[i].Digest = licensedigests[n+".xml"]
		v, e := validateLicense(licpath)
		if e != nil {
			liclist.SpdxLicense[i].Message = validationErrors(e)
			liclist.SpdxLicense[i].Valid = false
		} else {
			liclist.SpdxLicense[i].Valid = v
		}
	}
	jlic, jerr := json.Marshal(liclist)
	check(jerr)
	wjerr := ioutil.WriteFile(temppath+resrces["licenses.json"], jlic, 0666)
	check(wjerr)
}

func writeXML(filepath string, xsdstruct interface{}) string {
	f, err := os.Create(filepath)
	check(err)
	defer f.Close()
	var strct = xsdstruct
	output, err := xml.MarshalIndent(strct, "  ", "    ")
	check(err)
	ferr := ioutil.WriteFile(filepath, output, 0666)
	check(ferr)
	return filepath
}

func wgetF(fpath string, urlstr string) error {
	log.Println("Wget Save To: " + fpath)
	// Create output dir
	p := filepath.Dir(fpath)
	os.MkdirAll(p, os.ModePerm)
	newFile, err := os.Create(fpath)
	if err != nil {
		log.Fatal(err)
	}
	defer newFile.Close()
	// HTTP GET
	response, err := http.Get(urlstr)
	if err != nil {
		log.Fatal(err)
	}
	defer response.Body.Close()
	numBytesWritten, err := io.Copy(newFile, response.Body)
	if err != nil {
		log.Fatal(err)
	}
	log.Printf("Downloaded %d byte file.\n", numBytesWritten)
	return err
}

func check(e error) error {
	if e != nil {
		fmt.Printf("error: %v\n", e)
	}
	return e
}

func validateLicense(licensePath string) (bool, []error) {
	//log.Println("validateLicense")
	var xsddoc, derr = xsd.ParseFromFile(Tpath + resources["iep.xsd"])
	check(derr)
	lic, err := ioutil.ReadFile(licensePath)
	doc, err := libxml2.ParseString(fmt.Sprintf("%s", lic))
	check(err)
	if err := xsddoc.Validate(doc); err != nil {
		log.Println("Not Valid")
		return false, err.(xsd.SchemaValidationError).Errors()
	}
	return true, nil
}

func validationErrors(errors []error) string {
	errs := []ValErrs{}
	for _, errorMessage := range errors {
		errs = append(errs, ValErrs{Message: errorMessage.Error()})
	}
	allerrs, err := json.Marshal(errs)
	if err != nil {
		panic(err)
	}
	return fmt.Sprintf("%s", allerrs)
}
